import React from 'react'

interface AuthLayoutProps {
  children: React.ReactNode
}

export const AuthLayout = ({ children }: AuthLayoutProps) => {
  return (
    <div className="min-h-screen bg-black text-white">
      <div className="grid grid-cols-1 lg:grid-cols-2 min-h-screen">
        {/* Formulário */}
        <div className="flex items-center justify-center p-6 sm:p-12">
          <div className="w-full max-w-sm">
            {/* Logo */}
            <div className="mb-8 flex items-center justify-center">
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center font-bold text-black text-2xl">
                🐱
              </div>
            </div>
            {children}
          </div>
        </div>

        {/* Imagem (escondida em mobile) */}
        <div className="hidden lg:flex items-center justify-center p-12 bg-gradient-to-br from-gray-900 to-black">
          <div className="w-full h-full bg-gray-800 rounded-3xl flex items-center justify-center">
            <span className="text-gray-500">Imagem Hero</span>
          </div>
        </div>
      </div>
    </div>
  )
}
