'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/Button'
import { SimpleLineChart } from '@/components/SimpleLineChart'
import { Heatmap } from '@/components/Heatmap'
import { ChatWidget } from '@/components/ChatWidget'
import {
  mockChartData,
  mockHeatmapData,
  mockUser,
  mockStats,
  mockAccounts,
  mockCards,
  mockCardInvoices,
  mockTransactions,
  mockParcelamentos,
  mockCategories,
  mockSubscriptions,
  mockTopCategories
} from '@/lib/mockData'

type Tab = 'overview' | 'transactions' | 'parcelamentos' | 'assinaturas' | 'categorias' | 'cartoes'
type ParcelamentoTab = 'ongoing' | 'finished'
type SortOption = 'data' | 'valor' | 'nome'

// Componente DonutChart
const DonutChart = ({ data, total }: { data: { name: string; value: number; percentage: number }[]; total: number }) => {
  const colors = ['#10b981', '#6366f1', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899']

  let currentAngle = -90
  const paths: { path: string; color: string; label: string; percentage: number }[] = []

  data.forEach((item, idx) => {
    const sliceAngle = (item.percentage / 100) * 360
    const startAngle = currentAngle
    const endAngle = currentAngle + sliceAngle

    const startAngleRad = (startAngle * Math.PI) / 180
    const endAngleRad = (endAngle * Math.PI) / 180

    const x1 = 60 + 50 * Math.cos(startAngleRad)
    const y1 = 60 + 50 * Math.sin(startAngleRad)
    const x2 = 60 + 50 * Math.cos(endAngleRad)
    const y2 = 60 + 50 * Math.sin(endAngleRad)

    const ix1 = 60 + 30 * Math.cos(startAngleRad)
    const iy1 = 60 + 30 * Math.sin(startAngleRad)
    const ix2 = 60 + 30 * Math.cos(endAngleRad)
    const iy2 = 60 + 30 * Math.sin(endAngleRad)

    const largeArc = sliceAngle > 180 ? 1 : 0
    const path = `M ${ix1} ${iy1} L ${x1} ${y1} A 50 50 0 ${largeArc} 1 ${x2} ${y2} L ${ix2} ${iy2} A 30 30 0 ${largeArc} 0 ${ix1} ${iy1} Z`

    paths.push({
      path,
      color: colors[idx % colors.length],
      label: item.name,
      percentage: item.percentage
    })

    currentAngle = endAngle
  })

  return (
    <div className="flex flex-col gap-6">
      <div className="flex justify-center">
        <svg width="200" height="200" viewBox="0 0 120 120">
          {paths.map((p, idx) => (
            <path key={idx} d={p.path} fill={p.color} opacity="0.8" />
          ))}
          <circle cx="60" cy="60" r="30" fill="rgb(9, 9, 11)" />
          <text x="60" y="65" textAnchor="middle" fontSize="16" fill="white" fontWeight="bold">
            {data.reduce((a, b) => a + b.value, 0).toFixed(0)}
          </text>
        </svg>
      </div>
      <div className="space-y-2">
        {data.map((item, idx) => (
          <div key={idx} className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded" style={{ backgroundColor: colors[idx % colors.length] }}></div>
              <span className="text-gray-400">{item.name}</span>
            </div>
            <span className="font-semibold">{item.percentage}%</span>
          </div>
        ))}
      </div>
    </div>
  )
}

// Componente BarChart para Faturas
const InvoiceBarChart = ({ data }: { data: { month: string; amount: number }[] }) => {
  const maxAmount = Math.max(...data.map(d => d.amount))

  return (
    <div className="flex items-end justify-center gap-2 h-64">
      {data.map((item, idx) => {
        const height = (item.amount / maxAmount) * 100
        return (
          <div key={idx} className="flex flex-col items-center gap-2">
            <div
              className="w-12 bg-green-500 rounded transition hover:bg-green-400"
              style={{ height: `${height}%` }}
              title={`R$ ${item.amount.toFixed(2)}`}
            ></div>
            <span className="text-xs text-gray-400">{item.month}</span>
          </div>
        )
      })}
    </div>
  )
}

export default function DashboardPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [activeTab, setActiveTab] = useState<Tab>('overview')
  const [transactionFilter, setTransactionFilter] = useState('all')
  const [categoryFilter, setCategoryFilter] = useState('all')
  const [transactionSearch, setTransactionSearch] = useState('')
  const [parcelamentoTab, setParcelamentoTab] = useState<ParcelamentoTab>('ongoing')
  const [parcelamentoSort, setParcelamentoSort] = useState<SortOption>('data')
  const [currentMonth, setCurrentMonth] = useState(9)
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null)
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 5

  useEffect(() => {
    const userData = localStorage.getItem('user')
    if (!userData) {
      router.push('/login')
    } else {
      setUser(JSON.parse(userData))
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem('user')
    router.push('/login')
  }

  if (!user) return null

  // Filter transactions
  const filteredTransactions = mockTransactions.filter(t => {
    if (transactionFilter !== 'all' && t.type !== transactionFilter) return false
    if (categoryFilter !== 'all' && !t.category.includes(categoryFilter)) return false
    if (transactionSearch && !t.description.toLowerCase().includes(transactionSearch.toLowerCase())) return false
    return true
  })

  // Pagination for transactions
  const totalPages = Math.ceil(filteredTransactions.length / itemsPerPage)
  const paginatedTransactions = filteredTransactions.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  )

  // Filter parcelamentos
  const filteredParcelamentos = mockParcelamentos.filter(p => p.status === parcelamentoTab)
  const sortedParcelamentos = [...filteredParcelamentos].sort((a, b) => {
    switch (parcelamentoSort) {
      case 'valor':
        return b.monthly - a.monthly
      case 'nome':
        return a.name.localeCompare(b.name)
      case 'data':
      default:
        return new Date(a.startDate.split('/').reverse().join('-')).getTime() -
               new Date(b.startDate.split('/').reverse().join('-')).getTime()
    }
  })

  // Month navigation
  const monthNames = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
                      'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro']
  const currentMonthName = monthNames[currentMonth - 1] || 'Setembro'

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="border-b border-gray-800 bg-gray-950 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center font-bold text-black">
                🐱
              </div>
              <h1 className="text-xl font-bold">Pierre</h1>
            </div>
            <button
              onClick={handleLogout}
              className="text-sm text-gray-400 hover:text-red-400 transition font-medium"
            >
              ← Sair
            </button>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-400">Bem-vindo, <span className="text-white font-semibold">{user.name}</span></p>
          </div>
        </div>
      </header>

      {/* Tabs Navigation */}
      <div className="border-b border-gray-800 bg-gray-950/50 sticky top-16 z-10">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex gap-1 overflow-x-auto">
            {[
              { id: 'overview', label: '✅ Visão geral' },
              { id: 'transactions', label: '📋 Transações' },
              { id: 'parcelamentos', label: '🔄 Parcelamentos' },
              { id: 'assinaturas', label: '🔔 Assinaturas' },
              { id: 'categorias', label: '📊 Categorias' },
              { id: 'cartoes', label: '💳 Cartões' },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as Tab)
                  setCurrentPage(1)
                }}
                className={`
                  px-4 py-3 border-b-2 font-medium transition whitespace-nowrap
                  ${activeTab === tab.id
                    ? 'border-green-500 text-white'
                    : 'border-transparent text-gray-400 hover:text-white'
                  }
                `}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            {/* Hero Section */}
            <section>
              <h2 className="text-3xl font-bold mb-2">Seu dinheiro quer te contar uns segredos...</h2>
              <p className="text-gray-400 mb-6">
                Wagner, seus gastos estão 48% menores que no ano passado! Mandou bem!
              </p>

              {/* Interactive Card */}
              <div className="bg-gradient-to-r from-green-500/10 to-blue-500/10 border border-green-500/30 rounded-lg p-6 mb-8">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-lg font-bold mb-2">💬 Que tal bater um papo com o seu bolso?</h3>
                    <p className="text-gray-300 mb-4">
                      Converse com a inteligência artificial do Pierre para entender seus gastos e receber recomendações personalizadas.
                    </p>
                    <button className="bg-green-500 hover:bg-green-600 text-black font-semibold px-4 py-2 rounded transition">
                      Iniciar conversa
                    </button>
                  </div>
                  <span className="text-5xl">🤖</span>
                </div>
              </div>

              {/* Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <div className="bg-gray-950 border border-gray-800 rounded-lg p-6">
                  <h3 className="text-gray-400 text-sm font-medium">GASTO EM SETEMBRO</h3>
                  <p className="text-3xl font-bold mt-2">R$ {mockStats.gastoSetembro.toFixed(2)}</p>
                </div>
                <div className="bg-gray-950 border border-gray-800 rounded-lg p-6">
                  <h3 className="text-gray-400 text-sm font-medium">VS. MÊS ANTERIOR</h3>
                  <p className="text-3xl font-bold mt-2 text-green-500">📉 {mockStats.comparacaoAnterior}%</p>
                </div>
                <div className="bg-gray-950 border border-gray-800 rounded-lg p-6">
                  <h3 className="text-gray-400 text-sm font-medium">MAIOR GASTO</h3>
                  <p className="text-2xl font-bold mt-2">🏠 {mockStats.maiorGasto}</p>
                </div>
              </div>

              {/* Top Categories Section */}
              <div className="bg-gray-950 border border-gray-800 rounded-lg p-6 mb-8">
                <h3 className="text-lg font-bold mb-6">📊 PRINCIPAIS CATEGORIAS</h3>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-800">
                        <th className="text-left text-gray-400 text-sm font-medium pb-3">CATEGORIA</th>
                        <th className="text-right text-gray-400 text-sm font-medium pb-3">REAL</th>
                        <th className="text-right text-gray-400 text-sm font-medium pb-3">USO %</th>
                        <th className="text-right text-gray-400 text-sm font-medium pb-3">AÇÃO</th>
                      </tr>
                    </thead>
                    <tbody>
                      {mockTopCategories.map((cat, idx) => (
                        <tr key={idx} className="border-b border-gray-800 last:border-b-0 hover:bg-gray-900 transition">
                          <td className="py-3 text-white">{cat.name}</td>
                          <td className="text-right text-green-500 font-semibold">R$ {cat.value.toFixed(2)}</td>
                          <td className="text-right">
                            <div className="flex items-center justify-end gap-2">
                              <div className="w-16 bg-gray-800 rounded-full h-2">
                                <div className="bg-green-500 h-full rounded-full" style={{ width: `${cat.percentage}%` }}></div>
                              </div>
                              <span className="text-xs text-gray-400 min-w-fit">{cat.percentage}%</span>
                            </div>
                          </td>
                          <td className="text-right">
                            <button className="text-green-500 hover:text-green-400 font-medium text-sm transition">
                              →
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Charts Section */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                {/* Ritmo de Gastos */}
                <div className="bg-gray-950 border border-gray-800 rounded-lg p-6">
                  <h3 className="text-lg font-bold mb-4">📈 Ritmo de Gastos</h3>
                  <SimpleLineChart data={mockChartData} />
                </div>

                {/* Heatmap */}
                <div className="bg-gray-950 border border-gray-800 rounded-lg p-6">
                  <h3 className="text-lg font-bold mb-4">🔥 Mapa de Calor</h3>
                  <Heatmap data={mockHeatmapData} />
                  <div className="mt-4 pt-4 border-t border-gray-800">
                    <p className="text-xs text-gray-400 mb-2">Legenda:</p>
                    <div className="flex gap-2 items-center flex-wrap">
                      <span className="text-xs text-gray-400">Sem gastos</span>
                      <div className="w-3 h-3 rounded bg-gray-700"></div>
                      <span className="text-xs text-gray-400 ml-1">Pouco</span>
                      <div className="w-3 h-3 rounded bg-yellow-500"></div>
                      <span className="text-xs text-gray-400 ml-1">Médio</span>
                      <div className="w-3 h-3 rounded bg-red-500"></div>
                      <span className="text-xs text-gray-400 ml-1">Alto</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Recent Transactions */}
              <div className="bg-gray-950 border border-gray-800 rounded-lg p-6">
                <h3 className="text-lg font-bold mb-4">📝 TRANSAÇÕES RECENTES</h3>
                <div className="space-y-3">
                  {mockTransactions.slice(0, 5).map(tx => (
                    <div key={tx.id} className="flex justify-between items-center pb-3 border-b border-gray-800 last:border-b-0 hover:bg-gray-900 p-2 rounded transition">
                      <div className="flex gap-3 items-center">
                        <span className="text-2xl">{tx.icon}</span>
                        <div>
                          <p className="font-medium text-sm">{tx.description}</p>
                          <p className="text-xs text-gray-400">{tx.category} • {tx.date}</p>
                        </div>
                      </div>
                      <p className={`font-semibold ${tx.type === 'income' ? 'text-green-500' : 'text-red-500'}`}>
                        {tx.type === 'income' ? '+' : ''}R$ {Math.abs(tx.value).toFixed(2)}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Contas Correntes */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
                <div className="bg-gray-950 border border-gray-800 rounded-lg p-6">
                  <h3 className="text-gray-400 text-sm font-medium mb-4">CONTAS CORRENTES</h3>
                  <p className="text-3xl font-bold mb-4">R$ {mockAccounts.reduce((a, b) => a + b.balance, 0).toFixed(2)}</p>
                  <div className="space-y-3">
                    {mockAccounts.map(acc => (
                      <div key={acc.id} className="flex justify-between items-center pb-3 border-b border-gray-800 last:border-b-0">
                        <div>
                          <p className="font-medium">{acc.name}</p>
                          <p className="text-sm text-gray-400">{acc.type}</p>
                        </div>
                        <p className="font-semibold">R$ {acc.balance.toFixed(2)}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-gray-950 border border-gray-800 rounded-lg p-6">
                  <h3 className="text-gray-400 text-sm font-medium mb-4">LIMITE TOTAL DISPONÍVEL</h3>
                  <p className="text-3xl font-bold mb-2">R$ 10.768,28</p>
                  <p className="text-gray-400 text-sm mb-4">de R$ 14.500,00 de limite total</p>
                  <div className="bg-gray-800 rounded h-2">
                    <div className="bg-green-500 h-full rounded" style={{ width: '74%' }}></div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        )}

        {/* Transactions Tab */}
        {activeTab === 'transactions' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">Transações</h2>
              <button className="bg-green-500 hover:bg-green-600 text-black font-semibold px-4 py-2 rounded transition flex items-center gap-2">
                ➕ Nova Transação
              </button>
            </div>

            {/* Search and Filters */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <input
                type="text"
                placeholder="Buscar transações..."
                value={transactionSearch}
                onChange={(e) => {
                  setTransactionSearch(e.target.value)
                  setCurrentPage(1)
                }}
                className="bg-gray-900 border border-gray-800 rounded px-4 py-2 text-white focus:outline-none focus:border-green-500"
              />

              <select
                value={transactionFilter}
                onChange={(e) => {
                  setTransactionFilter(e.target.value)
                  setCurrentPage(1)
                }}
                className="bg-gray-900 border border-gray-800 rounded px-4 py-2 text-white focus:outline-none focus:border-green-500"
              >
                <option value="all">Todas as transações</option>
                <option value="income">Apenas receitas</option>
                <option value="expense">Apenas despesas</option>
              </select>

              <select
                value={categoryFilter}
                onChange={(e) => {
                  setCategoryFilter(e.target.value)
                  setCurrentPage(1)
                }}
                className="bg-gray-900 border border-gray-800 rounded px-4 py-2 text-white focus:outline-none focus:border-green-500"
              >
                <option value="all">Todas as categorias</option>
                <option value="Compras">Compras</option>
                <option value="Transferências">Transferências</option>
                <option value="Utensílios">Utensílios</option>
              </select>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-gray-950 border border-gray-800 rounded-lg p-4">
                <p className="text-gray-400 text-sm">Total</p>
                <p className="text-2xl font-bold">{filteredTransactions.length}</p>
              </div>
              <div className="bg-gray-950 border border-gray-800 rounded-lg p-4">
                <p className="text-gray-400 text-sm">Despesas</p>
                <p className="text-2xl font-bold text-red-500">
                  R$ {filteredTransactions.filter(t => t.type === 'expense').reduce((a, t) => a + t.value, 0).toFixed(2)}
                </p>
              </div>
              <div className="bg-gray-950 border border-gray-800 rounded-lg p-4">
                <p className="text-gray-400 text-sm">Receitas</p>
                <p className="text-2xl font-bold text-green-500">
                  R$ {filteredTransactions.filter(t => t.type === 'income').reduce((a, t) => a + t.value, 0).toFixed(2)}
                </p>
              </div>
            </div>

            {/* Table */}
            <div className="bg-gray-950 border border-gray-800 rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-800 bg-gray-900">
                      <th className="text-left text-gray-400 text-sm font-medium p-4">DESCRIÇÃO</th>
                      <th className="text-left text-gray-400 text-sm font-medium p-4">CATEGORIA</th>
                      <th className="text-left text-gray-400 text-sm font-medium p-4">CONTA</th>
                      <th className="text-left text-gray-400 text-sm font-medium p-4">DATA</th>
                      <th className="text-right text-gray-400 text-sm font-medium p-4">VALOR</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paginatedTransactions.length > 0 ? (
                      paginatedTransactions.map(tx => (
                        <tr key={tx.id} className="border-b border-gray-800 last:border-b-0 hover:bg-gray-900 transition">
                          <td className="p-4">
                            <div className="flex gap-2 items-center">
                              <span>{tx.icon}</span>
                              <span className="font-medium">{tx.description}</span>
                            </div>
                          </td>
                          <td className="p-4 text-gray-400 text-sm">{tx.category}</td>
                          <td className="p-4 text-gray-400 text-sm">{tx.account}</td>
                          <td className="p-4 text-gray-400 text-sm">{tx.date}</td>
                          <td className={`p-4 text-right font-semibold ${tx.type === 'income' ? 'text-green-500' : 'text-red-500'}`}>
                            {tx.type === 'income' ? '+' : ''}R$ {Math.abs(tx.value).toFixed(2)}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={5} className="p-8 text-center text-gray-400">
                          Nenhuma transação encontrada
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Pagination */}
              {filteredTransactions.length > 0 && (
                <div className="border-t border-gray-800 p-4 flex justify-between items-center">
                  <p className="text-sm text-gray-400">
                    Mostrando {((currentPage - 1) * itemsPerPage) + 1} a {Math.min(currentPage * itemsPerPage, filteredTransactions.length)} de {filteredTransactions.length}
                  </p>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                      disabled={currentPage === 1}
                      className="px-3 py-1 rounded border border-gray-800 text-gray-400 disabled:opacity-50 hover:border-green-500 transition"
                    >
                      ← Anterior
                    </button>
                    <div className="flex gap-1">
                      {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                        <button
                          key={page}
                          onClick={() => setCurrentPage(page)}
                          className={`px-3 py-1 rounded border transition ${
                            currentPage === page
                              ? 'border-green-500 bg-green-500/10 text-green-500'
                              : 'border-gray-800 text-gray-400 hover:border-green-500'
                          }`}
                        >
                          {page}
                        </button>
                      ))}
                    </div>
                    <button
                      onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                      disabled={currentPage === totalPages}
                      className="px-3 py-1 rounded border border-gray-800 text-gray-400 disabled:opacity-50 hover:border-green-500 transition"
                    >
                      Próxima →
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Parcelamentos Tab */}
        {activeTab === 'parcelamentos' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold mb-6">Parcelamentos</h2>

              {/* Stats */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                <div className="bg-gray-950 border border-gray-800 rounded-lg p-4">
                  <p className="text-gray-400 text-sm">EM ANDAMENTO</p>
                  <p className="text-2xl font-bold">{mockParcelamentos.filter(p => p.status === 'ongoing').length}</p>
                </div>
                <div className="bg-gray-950 border border-gray-800 rounded-lg p-4">
                  <p className="text-gray-400 text-sm">VALOR TOTAL</p>
                  <p className="text-2xl font-bold">R$ 8.078,05</p>
                </div>
                <div className="bg-gray-950 border border-gray-800 rounded-lg p-4">
                  <p className="text-gray-400 text-sm">JÁ PAGO</p>
                  <p className="text-2xl font-bold text-green-500">R$ 4.502,50</p>
                </div>
                <div className="bg-gray-950 border border-gray-800 rounded-lg p-4">
                  <p className="text-gray-400 text-sm">PROGRESSO</p>
                  <p className="text-2xl font-bold">56%</p>
                </div>
              </div>

              {/* Tabs */}
              <div className="flex gap-4 mb-6 border-b border-gray-800">
                <button
                  onClick={() => {
                    setParcelamentoTab('ongoing')
                    setParcelamentoSort('data')
                  }}
                  className={`px-4 py-3 border-b-2 font-medium transition ${
                    parcelamentoTab === 'ongoing'
                      ? 'border-green-500 text-white'
                      : 'border-transparent text-gray-400 hover:text-white'
                  }`}
                >
                  Em andamento ({mockParcelamentos.filter(p => p.status === 'ongoing').length})
                </button>
                <button
                  onClick={() => {
                    setParcelamentoTab('finished')
                    setParcelamentoSort('data')
                  }}
                  className={`px-4 py-3 border-b-2 font-medium transition ${
                    parcelamentoTab === 'finished'
                      ? 'border-green-500 text-white'
                      : 'border-transparent text-gray-400 hover:text-white'
                  }`}
                >
                  Finalizadas ({mockParcelamentos.filter(p => p.status === 'finished').length})
                </button>
              </div>

              {/* Sort Button */}
              <div className="mb-6 flex justify-end">
                <div className="relative">
                  <select
                    value={parcelamentoSort}
                    onChange={(e) => setParcelamentoSort(e.target.value as SortOption)}
                    className="bg-gray-900 border border-gray-800 rounded px-4 py-2 text-sm text-gray-400 focus:outline-none focus:border-green-500 cursor-pointer hover:text-white transition"
                  >
                    <option value="data">Ordenar por: Data</option>
                    <option value="valor">Ordenar por: Valor</option>
                    <option value="nome">Ordenar por: Nome</option>
                  </select>
                </div>
              </div>

              {/* Parcelamentos Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {sortedParcelamentos.map(parc => (
                  <div key={parc.id} className="bg-gray-950 border border-gray-800 rounded-lg p-5 hover:border-green-500/50 transition">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex gap-3">
                        <span className="text-3xl">{parc.icon}</span>
                        <div className="flex-1">
                          <p className="font-bold text-lg">{parc.name}</p>
                          <p className="text-sm text-gray-400">{parc.parcels} • Iniciado em {parc.startDate}</p>
                        </div>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="mb-4">
                      <div className="w-full bg-gray-800 rounded-full h-2 mb-2">
                        <div
                          className="bg-green-500 h-full rounded-full"
                          style={{ width: `${(parseFloat(parc.parcels.split('/')[0]) / parseFloat(parc.parcels.split('/')[1])) * 100}%` }}
                        ></div>
                      </div>
                      <p className="text-xs text-gray-400">
                        {parc.parcels}
                      </p>
                    </div>

                    {/* Details */}
                    <div className="grid grid-cols-2 gap-3 pt-4 border-t border-gray-800">
                      <div>
                        <p className="text-xs text-gray-400 mb-1">Valor/mês</p>
                        <p className="font-semibold">R$ {parc.monthly.toFixed(2)}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400 mb-1">Restante</p>
                        <p className="font-semibold text-green-500">R$ {parc.remaining.toFixed(2)}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {sortedParcelamentos.length === 0 && (
                <div className="bg-gray-950 border border-gray-800 rounded-lg p-8 text-center">
                  <p className="text-gray-400">Nenhum parcelamento {parcelamentoTab === 'ongoing' ? 'em andamento' : 'finalizado'}</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Assinaturas Tab */}
        {activeTab === 'assinaturas' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold mb-6">Assinaturas Ativas</h2>

            {mockSubscriptions.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {mockSubscriptions.map(sub => (
                  <div key={sub.id} className="bg-gray-950 border border-gray-800 rounded-lg p-5 hover:border-green-500/50 transition">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex gap-3 flex-1">
                        <span className="text-3xl">{sub.icon}</span>
                        <div className="flex-1">
                          <p className="font-bold text-lg">{sub.name}</p>
                          <p className="text-xs text-gray-400">{sub.category}</p>
                        </div>
                      </div>
                    </div>

                    <div className="pt-4 border-t border-gray-800 space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-400">Valor mensal</span>
                        <span className="font-semibold">R$ {sub.value.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-400">Próxima cobrança</span>
                        <span className="text-sm font-medium">{sub.nextBilling}</span>
                      </div>
                      <button className="w-full mt-2 text-xs border border-gray-700 rounded py-2 text-gray-400 hover:text-red-400 hover:border-red-500 transition">
                        Cancelar assinatura
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-gray-950 border border-gray-800 rounded-lg p-12 text-center">
                <p className="text-gray-400 mb-2">Nenhuma assinatura detectada</p>
                <p className="text-gray-500 text-sm">
                  Assinaturas como Netflix, Spotify e outras serão detectadas automaticamente.
                </p>
              </div>
            )}
          </div>
        )}

        {/* Categorias Tab */}
        {activeTab === 'categorias' && (
          <div className="space-y-8">
            <div>
              <h2 className="text-2xl font-bold mb-2">Categorias</h2>

              {/* Month Navigation */}
              <div className="flex items-center justify-between mb-8">
                <button
                  onClick={() => setCurrentMonth(Math.max(1, currentMonth - 1))}
                  className="text-gray-400 hover:text-white transition"
                >
                  ←
                </button>
                <p className="text-lg font-semibold">{currentMonthName} De 2026</p>
                <button
                  onClick={() => setCurrentMonth(Math.min(12, currentMonth + 1))}
                  className="text-gray-400 hover:text-white transition"
                >
                  →
                </button>
              </div>

              {/* Donut Chart */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                <div className="bg-gray-950 border border-gray-800 rounded-lg p-6">
                  <h3 className="text-lg font-bold mb-6">Distribuição de Gastos</h3>
                  <DonutChart
                    data={mockCategories.map(cat => ({
                      name: cat.name,
                      value: cat.value,
                      percentage: cat.percentage
                    }))}
                    total={mockCategories.reduce((a, b) => a + b.value, 0)}
                  />
                </div>

                <div className="bg-gray-950 border border-gray-800 rounded-lg p-6">
                  <h3 className="text-lg font-bold mb-4">Resumo</h3>
                  <div className="space-y-4">
                    <div>
                      <p className="text-gray-400 text-sm mb-1">Total gasto</p>
                      <p className="text-3xl font-bold">R$ {mockCategories.reduce((a, b) => a + b.value, 0).toFixed(2)}</p>
                    </div>
                    <div className="pt-4 border-t border-gray-800">
                      <p className="text-gray-400 text-sm mb-3">Maior categoria</p>
                      <div className="flex justify-between items-center">
                        <span>Compras</span>
                        <span className="font-semibold">R$ 492,10</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Categories List */}
              <div className="space-y-3">
                {mockCategories.map((cat, idx) => (
                  <div key={idx} className="bg-gray-950 border border-gray-800 rounded-lg">
                    <button
                      onClick={() => setExpandedCategory(expandedCategory === cat.name ? null : cat.name)}
                      className="w-full p-4 flex items-center justify-between hover:bg-gray-900 transition"
                    >
                      <div className="flex items-center gap-3 flex-1">
                        <span className="text-2xl">{cat.icon}</span>
                        <div className="text-left">
                          <p className="font-bold">{cat.name}</p>
                          <p className="text-sm text-gray-400">R$ {cat.value.toFixed(2)}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p className="text-sm text-gray-400">{cat.percentage}%</p>
                        </div>
                        <span className="text-gray-400">{expandedCategory === cat.name ? '▼' : '▶'}</span>
                      </div>
                    </button>

                    {/* Subcategories */}
                    {expandedCategory === cat.name && cat.subcategories && (
                      <div className="border-t border-gray-800 bg-gray-900/50">
                        {cat.subcategories.map((subcat, sidx) => (
                          <div key={sidx} className="p-4 border-b border-gray-800 last:border-b-0 flex justify-between items-center hover:bg-gray-800 transition">
                            <div className="flex items-center gap-3 ml-8">
                              <span className="text-xl">◦</span>
                              <span className="text-gray-300">{subcat.name}</span>
                            </div>
                            <span className="text-green-500 font-semibold">R$ {subcat.value.toFixed(2)}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Cartões Tab */}
        {activeTab === 'cartoes' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold mb-6">Cartões</h2>

            {mockCards.map(card => (
              <div key={card.id} className="space-y-4">
                {/* Card Info */}
                <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-6 text-white">
                  <div className="flex justify-between items-start mb-8">
                    <div>
                      <p className="text-sm opacity-80">CARTÃO</p>
                      <p className="text-2xl font-bold">{card.name}</p>
                    </div>
                    <p className="text-right">
                      <p className="text-xs opacity-80">VENCE EM</p>
                      <p className="text-lg font-bold">{card.dueDate}</p>
                    </p>
                  </div>
                  <div className="flex justify-between items-end">
                    <p className="text-lg tracking-wider">•••• •••• •••• {card.lastDigits}</p>
                    <p className="text-sm">{card.brand}</p>
                  </div>
                </div>

                {/* Alert */}
                <div className="bg-orange-500/10 border border-orange-500/30 rounded-lg p-4">
                  <p className="text-sm text-orange-400">
                    ⚠️ Fatura estimada para o mês: <span className="font-semibold">R$ {card.limitUsed.toFixed(2)}</span>
                  </p>
                </div>

                {/* Details Grid */}
                <div className="grid grid-cols-3 gap-4 mb-6">
                  <div className="bg-gray-950 border border-gray-800 rounded-lg p-4">
                    <p className="text-gray-400 text-sm mb-2">Limite total</p>
                    <p className="text-2xl font-bold">R$ {(card.limitTotal / 1000).toFixed(1)}k</p>
                  </div>
                  <div className="bg-gray-950 border border-gray-800 rounded-lg p-4">
                    <p className="text-gray-400 text-sm mb-2">Usado</p>
                    <p className="text-2xl font-bold">R$ {(card.limitUsed / 1000).toFixed(1)}k</p>
                  </div>
                  <div className="bg-gray-950 border border-gray-800 rounded-lg p-4">
                    <p className="text-gray-400 text-sm mb-2">Disponível</p>
                    <p className="text-2xl font-bold text-green-500">R$ {((card.limitTotal - card.limitUsed) / 1000).toFixed(1)}k</p>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="bg-gray-950 border border-gray-800 rounded-lg p-4 mb-6">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-400 text-sm">Utilização</span>
                    <span className="font-semibold">{((card.limitUsed / card.limitTotal) * 100).toFixed(1)}%</span>
                  </div>
                  <div className="w-full bg-gray-800 rounded-full h-3">
                    <div
                      className="bg-gradient-to-r from-green-500 to-yellow-500 h-full rounded-full"
                      style={{ width: `${(card.limitUsed / card.limitTotal) * 100}%` }}
                    ></div>
                  </div>
                </div>

                {/* Invoice History */}
                <div className="bg-gray-950 border border-gray-800 rounded-lg p-6">
                  <h3 className="text-lg font-bold mb-6">Faturas Anteriores</h3>
                  <InvoiceBarChart data={mockCardInvoices} />
                </div>

                {/* Divider */}
                {mockCards.indexOf(card) < mockCards.length - 1 && (
                  <div className="border-b border-gray-800 my-8"></div>
                )}
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Chat Widget */}
      <ChatWidget />
    </div>
  )
}
