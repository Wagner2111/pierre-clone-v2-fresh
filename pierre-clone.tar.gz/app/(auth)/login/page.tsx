'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { AuthLayout } from '@/components/AuthLayout'
import { Input } from '@/components/Input'
import { Button } from '@/components/Button'

type LoginTab = 'whatsapp' | 'email'

export default function LoginPage() {
  const router = useRouter()
  const [tab, setTab] = useState<LoginTab>('email')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [formData, setFormData] = useState({
    whatsapp: '',
    email: '',
    password: '',
  })

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
    setError('')
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      // Simulação de login
      if (tab === 'email' && !formData.email) {
        setError('Email é obrigatório')
        return
      }
      if (!formData.password) {
        setError('Senha é obrigatória')
        return
      }

      // Simular delay de API
      await new Promise(resolve => setTimeout(resolve, 1000))

      // Salvar estado no localStorage (temporário)
      localStorage.setItem('user', JSON.stringify({
        email: formData.email || formData.whatsapp,
        name: 'Wagner',
      }))

      router.push('/dashboard')
    } catch (err) {
      setError('Erro ao fazer login')
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Entre na sua conta</h1>
        </div>

        {error && (
          <div className="bg-red-500/20 border border-red-500 text-red-200 px-4 py-3 rounded-lg">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Email Tab */}
          {tab === 'email' && (
            <>
              <Input
                type="email"
                placeholder="Digite seu email"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
              />
              <Input
                type="password"
                placeholder="Digite sua senha"
                value={formData.password}
                onChange={(e) => handleInputChange('password', e.target.value)}
                toggleVisibility
              />
            </>
          )}

          {/* WhatsApp Tab */}
          {tab === 'whatsapp' && (
            <>
              <div className="flex gap-2">
                <input
                  type="text"
                  value="+55"
                  disabled
                  className="w-20 px-3 py-3 bg-gray-900 border border-gray-700 rounded-lg text-white disabled:opacity-50"
                />
                <Input
                  type="tel"
                  placeholder="Número WhatsApp"
                  value={formData.whatsapp}
                  onChange={(e) => handleInputChange('whatsapp', e.target.value)}
                  className="flex-1"
                />
              </div>
              <Input
                type="password"
                placeholder="Digite sua senha"
                value={formData.password}
                onChange={(e) => handleInputChange('password', e.target.value)}
                toggleVisibility
              />
            </>
          )}

          <Link href="/forgot-password" className="text-sm text-gray-400 hover:text-white">
            Esqueceu a senha?
          </Link>

          <Button type="submit" variant="primary" disabled={loading}>
            {loading ? 'Entrando...' : 'Entrar'}
          </Button>

          <Link href="/register">
            <Button type="button" variant="secondary">
              Criar conta
            </Button>
          </Link>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-700"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-black text-gray-400">ou</span>
            </div>
          </div>

          {tab === 'email' && (
            <Button
              type="button"
              variant="secondary"
              onClick={() => setTab('whatsapp')}
            >
              💬 Logar com WhatsApp
            </Button>
          )}

          {tab === 'whatsapp' && (
            <Button
              type="button"
              variant="secondary"
              onClick={() => setTab('email')}
            >
              📧 Logar com E-mail
            </Button>
          )}

          <Button type="button" variant="secondary">
            🔍 Continuar com Google
          </Button>

          <Button type="button" variant="secondary">
            🍎 Continuar com Apple
          </Button>
        </form>

        <div className="text-center text-xs text-gray-500 mt-6 pt-4 border-t border-gray-800">
          <p>
            Ao continuar você concorda com os{' '}
            <Link href="/terms" className="text-gray-400 hover:text-white underline">
              Termos de uso
            </Link>
          </p>
        </div>
      </div>
    </AuthLayout>
  )
}
