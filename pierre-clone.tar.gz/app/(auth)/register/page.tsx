'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { AuthLayout } from '@/components/AuthLayout'
import { Input } from '@/components/Input'
import { Button } from '@/components/Button'

export default function RegisterPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [whatsapp, setWhatsapp] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      if (!whatsapp) {
        setError('WhatsApp é obrigatório')
        return
      }

      await new Promise(resolve => setTimeout(resolve, 1000))

      localStorage.setItem('user', JSON.stringify({
        whatsapp: whatsapp,
        name: 'Novo Usuário',
      }))

      router.push('/dashboard')
    } catch (err) {
      setError('Erro ao criar conta')
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Boas vindas!</h1>
          <p className="text-gray-400">Qual é o seu número de WhatsApp?</p>
        </div>

        {error && (
          <div className="bg-red-500/20 border border-red-500 text-red-200 px-4 py-3 rounded-lg">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex gap-2">
            <input
              type="text"
              value="+55"
              disabled
              className="w-20 px-3 py-3 bg-gray-900 border border-gray-700 rounded-lg text-white disabled:opacity-50"
            />
            <Input
              type="tel"
              placeholder="Número do WhatsApp"
              value={whatsapp}
              onChange={(e) => {
                setWhatsapp(e.target.value)
                setError('')
              }}
              className="flex-1"
            />
          </div>

          <Button
            type="submit"
            variant="primary"
            disabled={loading || !whatsapp}
          >
            {loading ? 'Processando...' : 'Começar'}
          </Button>
        </form>

        <div className="text-center text-sm">
          <span className="text-gray-400">
            Já tem uma conta?{' '}
            <Link href="/login" className="text-white hover:text-gray-300 underline font-medium">
              Fazer login
            </Link>
          </span>
        </div>
      </div>
    </AuthLayout>
  )
}
